#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
将Markdown格式的软件说明书转换为docx格式

依赖安装：
    pip install -r requirements.txt

使用方法：
    python docs/md_to_docx.py
"""

import os
import sys
from pathlib import Path
import markdown
from docx import Document
from docx.shared import Inches
from bs4 import BeautifulSoup

class MDToDocxConverter:
    """Markdown到docx格式转换器"""
    
    def __init__(self):
        self.document = Document()
    
    def add_title(self, title):
        """添加标题"""
        self.document.add_heading(title, 0)
    
    def add_heading(self, text, level=1):
        """添加各级标题"""
        self.document.add_heading(text, level=level)
    
    def add_paragraph(self, text):
        """添加段落"""
        if text.strip():
            self.document.add_paragraph(text)
    
    def add_code_block(self, code, language=None):
        """添加代码块"""
        # 在Word中使用等宽字体表示代码
        p = self.document.add_paragraph()
        p.add_run(code).font.name = "Consolas"
    
    def add_list(self, items, is_ordered=False):
        """添加列表"""
        for item in items:
            if is_ordered:
                self.document.add_paragraph(item, style="List Number")
            else:
                self.document.add_paragraph(item, style="List Bullet")
    
    def convert_html_to_docx(self, html_content):
        """将HTML内容转换为docx格式"""
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # 处理标题和内容
        for element in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'pre', 'ul', 'ol']):
            if element.name.startswith('h'):
                level = int(element.name[1])
                # markdown库转换的h1在Word中作为一级标题
                self.add_heading(element.get_text(), level=level)
            elif element.name == 'p':
                self.add_paragraph(element.get_text())
            elif element.name == 'pre':
                # 处理代码块
                code = element.get_text()
                self.add_code_block(code)
            elif element.name == 'ul':
                # 处理无序列表
                items = [li.get_text() for li in element.find_all('li')]
                self.add_list(items, is_ordered=False)
            elif element.name == 'ol':
                # 处理有序列表
                items = [li.get_text() for li in element.find_all('li')]
                self.add_list(items, is_ordered=True)
    
    def convert_file(self, md_path, docx_path):
        """将Markdown文件转换为docx文件"""
        try:
            # 读取Markdown文件
            with open(md_path, 'r', encoding='utf-8') as f:
                md_content = f.read()
            
            # 提取标题（第一行，以#开头的行）
            lines = md_content.split('\n')
            title = "软件说明书"
            if lines and lines[0].startswith('#'):
                title = lines[0].lstrip('#').strip()
            
            # 添加标题
            self.add_title(title)
            
            # 将Markdown转换为HTML
            html_content = markdown.markdown(md_content)
            
            # 将HTML转换为docx
            self.convert_html_to_docx(html_content)
            
            # 保存docx文件
            self.document.save(docx_path)
            
            print(f"转换成功！已生成: {docx_path}")
            return True
        except Exception as e:
            print(f"转换失败: {str(e)}")
            return False

if __name__ == "__main__":
    # 获取当前脚本所在目录
    current_dir = Path(__file__).parent
    
    # 设置输入和输出文件路径
    md_file = current_dir / "软件说明书.md"
    docx_file = current_dir / "软件说明书.docx"
    
    # 检查输入文件是否存在
    if not md_file.exists():
        print(f"错误：找不到Markdown文件: {md_file}")
        sys.exit(1)
    
    # 创建转换器并执行转换
    converter = MDToDocxConverter()
    converter.convert_file(md_file, docx_file)