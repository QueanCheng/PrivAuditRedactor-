# 规则说明单（软著材料）

以下为本软件内置的 521 条正则规则说明，每条规则包含风险级别、适用场景、示例及脱敏建议。

## 规则 1: email_generic

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user.test+100@example.com

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 2: phone_cn_simple

- **正则**: `\b1[3-9]\d{9}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 13800138000

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 3: phone_int_plus

- **正则**: `\+\d{1,3}[-\s]?\d{4,14}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: +44-7700900900

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 4: id_card_cn

- **正则**: `\b\d{6}(19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[0-9Xx]\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 110101199003071234

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 5: bank_card_13_19

- **正则**: `\b\d{12,19}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 4532738771091795

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 6: ipv4

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 192.168.0.1

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 7: passport_cn_GE

- **正则**: `\b[GE]\d{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: G12345678

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 8: ssn_us

- **正则**: `\b\d{3}-\d{2}-\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 123-45-6789

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 9: plate_cn

- **正则**: `\b[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣桂甘晋蒙陕吉闽贵粤青藏川宁琼][A-Z][A-Z0-9]{4,5}[A-Z0-9挂学警港澳]\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 京A12345

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 10: url_http

- **正则**: `https?://[^\s)]+`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: https://example.com/path?query=1

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 11: uuid

- **正则**: `\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 3fa85f64-5717-4562-b3fc-2c963f66afa6

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 12: email_variation_1

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user1@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 13: mobile_space_2

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1002-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 14: token_base64_like_3

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 15: order_no_4

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100004

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 16: log_token_param_5

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 17: invoice_no_6

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200006

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 18: hex_32_7

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: c1c91ff91315a7045891dba535fb8b0f

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 19: uuid_nohyphen_8

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: b5f90ac8fc4a4a983b2ca319ec6afe4e

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 20: short_uuid_9

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 98b6e4e7

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 21: short_uuid_10

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 1fd0594d

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 22: email_variation_11

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user11@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 23: mobile_space_12

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1012-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 24: token_base64_like_13

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 25: order_no_14

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100014

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 26: log_token_param_15

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 27: invoice_no_16

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200016

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 28: hex_32_17

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: e452231fa4e2ac7e2c12892ff118ad9e

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 29: uuid_nohyphen_18

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: eabd2f29ea43695e1b0e9362cdae545f

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 30: short_uuid_19

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: f5860f64

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 31: short_uuid_20

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: df8d6847

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 32: email_variation_21

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user21@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 33: mobile_space_22

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1022-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 34: token_base64_like_23

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 35: order_no_24

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100024

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 36: log_token_param_25

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 37: invoice_no_26

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200026

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 38: hex_32_27

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 5c22d153fadff29460cc24683b8c3aeb

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 39: uuid_nohyphen_28

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: f386e50840af800e207eeeb83d18b75c

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 40: short_uuid_29

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: bf323707

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 41: short_uuid_30

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 0efc9468

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 42: email_variation_31

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user31@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 43: mobile_space_32

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1032-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 44: token_base64_like_33

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 45: order_no_34

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100034

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 46: log_token_param_35

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 47: invoice_no_36

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200036

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 48: hex_32_37

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 9af613f67bf86b00d971ebcdde425bad

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 49: uuid_nohyphen_38

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 90e89732084ec1d97b445d61150c67b1

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 50: short_uuid_39

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 33c0cff6

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 51: short_uuid_40

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 476aafe0

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 52: email_variation_41

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user41@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 53: mobile_space_42

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1042-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 54: token_base64_like_43

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 55: order_no_44

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100044

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 56: log_token_param_45

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 57: invoice_no_46

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200046

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 58: hex_32_47

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: c4a6f84ae90d0592ce06b3dc62cda7a9

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 59: uuid_nohyphen_48

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 4168b18a0e2994869bd4fe346e859406

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 60: short_uuid_49

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ac52abb1

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 61: short_uuid_50

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 8b328c21

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 62: email_variation_51

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user51@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 63: mobile_space_52

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1052-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 64: token_base64_like_53

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 65: order_no_54

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100054

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 66: log_token_param_55

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 67: invoice_no_56

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200056

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 68: hex_32_57

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 309abd446c424db63551221697d4035d

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 69: uuid_nohyphen_58

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 4367add8acb34e4567ba9daedb681d83

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 70: short_uuid_59

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 33afccd6

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 71: short_uuid_60

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: d01e511c

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 72: email_variation_61

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user61@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 73: mobile_space_62

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1062-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 74: token_base64_like_63

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 75: order_no_64

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100064

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 76: log_token_param_65

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 77: invoice_no_66

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200066

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 78: hex_32_67

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dbd1536ac48e2cf2ce5e2792ba340d4c

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 79: uuid_nohyphen_68

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: d0ba764812735fbc9ade60d1366c2597

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 80: short_uuid_69

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 3bae847f

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 81: short_uuid_70

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: b2298b7a

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 82: email_variation_71

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user71@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 83: mobile_space_72

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1072-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 84: token_base64_like_73

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 85: order_no_74

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100074

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 86: log_token_param_75

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 87: invoice_no_76

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200076

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 88: hex_32_77

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: b2cff5f8edfcb19e3c482ee88326084d

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 89: uuid_nohyphen_78

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: a53b31e50b1f0afbed0f3571ec789f2a

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 90: short_uuid_79

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: a339d8d1

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 91: short_uuid_80

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 1eadda4f

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 92: email_variation_81

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user81@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 93: mobile_space_82

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1082-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 94: token_base64_like_83

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 95: order_no_84

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100084

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 96: log_token_param_85

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 97: invoice_no_86

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200086

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 98: hex_32_87

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 0873081faff94ee43a295d692d13713e

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 99: uuid_nohyphen_88

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 9efc3da457a8e2f1a836d8bf422e0b28

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 100: short_uuid_89

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: a3065a87

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 101: short_uuid_90

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: c0a8683d

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 102: email_variation_91

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user91@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 103: mobile_space_92

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1092-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 104: token_base64_like_93

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 105: order_no_94

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100094

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 106: log_token_param_95

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 107: invoice_no_96

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200096

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 108: hex_32_97

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: f6c0acde5d7e483c81a40ec2b5988388

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 109: uuid_nohyphen_98

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 8ef71eae0de69a4859b4d7e5e0925f74

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 110: short_uuid_99

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 408aa86d

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 111: short_uuid_100

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: e4bb3b1b

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 112: email_variation_101

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user101@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 113: mobile_space_102

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1102-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 114: token_base64_like_103

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 115: order_no_104

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100104

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 116: log_token_param_105

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 117: invoice_no_106

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200106

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 118: hex_32_107

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 4748ad847692fb1cf43cf03e3cfc3c9f

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 119: uuid_nohyphen_108

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: d6db8b7528bce102a9f7515539d1bbe9

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 120: short_uuid_109

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 70db7b1c

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 121: short_uuid_110

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 3aab15a4

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 122: email_variation_111

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user111@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 123: mobile_space_112

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1112-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 124: token_base64_like_113

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 125: order_no_114

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100114

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 126: log_token_param_115

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 127: invoice_no_116

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200116

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 128: hex_32_117

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ae9fd3ede437f079d1a5d84662a52859

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 129: uuid_nohyphen_118

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 158c9f46202dde71225c4a5c7cf95619

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 130: short_uuid_119

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 043b225e

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 131: short_uuid_120

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 63e4efcc

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 132: email_variation_121

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user121@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 133: mobile_space_122

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1122-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 134: token_base64_like_123

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 135: order_no_124

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100124

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 136: log_token_param_125

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 137: invoice_no_126

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200126

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 138: hex_32_127

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 2e14cf5f68725da26d7e737a49044509

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 139: uuid_nohyphen_128

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: b899baed52b66a96385a5c07800fb1f3

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 140: short_uuid_129

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 9aa7fb54

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 141: short_uuid_130

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 6d02275d

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 142: email_variation_131

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user131@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 143: mobile_space_132

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1132-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 144: token_base64_like_133

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 145: order_no_134

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100134

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 146: log_token_param_135

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 147: invoice_no_136

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200136

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 148: hex_32_137

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: a9820fb33628610a38b3bc7dabc31299

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 149: uuid_nohyphen_138

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 495abee42d0d75104a215d7dbc900dc7

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 150: short_uuid_139

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 5db0e4c1

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 151: short_uuid_140

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 4dfa331b

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 152: email_variation_141

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user141@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 153: mobile_space_142

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1142-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 154: token_base64_like_143

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 155: order_no_144

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100144

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 156: log_token_param_145

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 157: invoice_no_146

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200146

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 158: hex_32_147

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 19567b7682dfdfdda7aaf17360877acd

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 159: uuid_nohyphen_148

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: b6f6659a034c322335b9dad5d5262d3d

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 160: short_uuid_149

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: d71e8535

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 161: short_uuid_150

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: b493d8fa

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 162: email_variation_151

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: user151@sub.example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 163: mobile_space_152

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 138-1152-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 164: token_base64_like_153

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: dGhpcy1pc19hLXRlc3Qtc3RyaW5nLXRvLW1hdGNo

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 165: order_no_154

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: ORD-100154

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 166: log_token_param_155

- **正则**: `token=[0-9a-zA-Z\-_.]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: token=abc123DEF_456-xyz

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 167: invoice_no_156

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: INV200156

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 168: hex_32_157

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: a504ea4659b0186356623b57c6a8bb90

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 169: uuid_nohyphen_158

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: f2e47754071da9f8330104c956ac6b18

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 170: short_uuid_159

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 577b8e0e

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 171: short_uuid_160

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: c75c8386

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 172: iban_simple

- **正则**: `\b[A-Z]{2}\d{2}[A-Z0-9]{4,30}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: GB29NWBK60161331926819

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 173: swift_bic

- **正则**: `\b[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: NWBKGB2L

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 174: visa_card

- **正则**: `\b4[0-9]{12}(?:[0-9]{3})?\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 4111111111111111

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 175: mastercard

- **正则**: `\b5[1-5][0-9]{14}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 5500000000000004

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 176: amex

- **正则**: `\b3[47][0-9]{13}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 340000000000009

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 177: diners

- **正则**: `\b3(?:0[0-5]|[68][0-9])[0-9]{11}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 30569309025904

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 178: discover

- **正则**: `\b6(?:011|5[0-9]{2})[0-9]{12}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 6011111111111117

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 179: mac_addr

- **正则**: `\b(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 00:1A:2B:3C:4D:5E

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 180: lat_lon

- **正则**: `\b-?\d{1,3}\.\d+,\s*-?\d{1,3}\.\d+\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 37.7749,-122.4194

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 181: datetime_iso

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 2023-08-01T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 182: date_ymd

- **正则**: `\b\d{4}-\d{2}-\d{2}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 2020-01-15

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 183: time_hms

- **正则**: `\b\d{2}:\d{2}:\d{2}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 14:23:01

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 184: ipv6

- **正则**: `\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 2001:0db8:85a3:0000:0000:8a2e:0370:7334

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 185: mqtt_clientid

- **正则**: `\bclientId=[A-Za-z0-9_-]{1,64}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: clientId=my-device-01

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 186: jwt_like

- **正则**: `[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: eyJhbGciOiJIUzI1NiIsInR...

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 187: vin

- **正则**: `\b[0-9A-HJ-NPR-Z]{17}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 1HGCM82633A004352

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 188: passport_generic

- **正则**: `\b[A-PR-WY][1-9]\d\s?\d{4}[1-9]\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: P1234567

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 189: cn_bank_name

- **正则**: `(中国银行|工商银行|建设银行|农业银行|招商银行)`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 工商银行

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 190: cn_address_short

- **正则**: `(市|省|区|县|路|街|号)\d{1,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 朝阳区100号

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 191: cn_name_simple

- **正则**: `[\u4e00-\u9fff]{2,4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 张三丰

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 192: employee_id

- **正则**: `\bEID[-_]?\d{3,8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: EID-000123

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 193: student_id

- **正则**: `\bS\d{6,10}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: S20230001

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 194: tracking_cn

- **正则**: `\b\d{14,16}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: 12345678901234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 195: container_no

- **正则**: `\b[A-Z]{4}\d{7}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: MSCU1234567

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 196: us_phone_paren

- **正则**: `\(\d{3}\)\s*\d{3}-\d{4}`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: (415) 555-2671

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 197: generic_seq_197

- **正则**: `\bTOKEN197[A-Z]{3,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: TOKEN197XYZ

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 198: generic_seq_198

- **正则**: `\bREF198[: ]\d{2,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: REF198: 55

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 199: generic_seq_199

- **正则**: `\bCODE199[:\-]?\d{4,8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: CODE199-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 200: generic_seq_200

- **正则**: `\bTOKEN200[A-Z]{3,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: TOKEN200XYZ

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 201: generic_seq_201

- **正则**: `\bREF201[: ]\d{2,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: REF201: 55

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 202: generic_seq_202

- **正则**: `\bCODE202[:\-]?\d{4,8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: CODE202-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 203: generic_seq_203

- **正则**: `\bTOKEN203[A-Z]{3,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: TOKEN203XYZ

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 204: generic_seq_204

- **正则**: `\bREF204[: ]\d{2,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: REF204: 55

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 205: generic_seq_205

- **正则**: `\bCODE205[:\-]?\d{4,8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: CODE205-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 206: generic_seq_206

- **正则**: `\bTOKEN206[A-Z]{3,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: TOKEN206XYZ

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 207: generic_seq_207

- **正则**: `\bREF207[: ]\d{2,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: REF207: 55

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 208: generic_seq_208

- **正则**: `\bCODE208[:\-]?\d{4,8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: CODE208-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 209: generic_seq_209

- **正则**: `\bTOKEN209[A-Z]{3,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: TOKEN209XYZ

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 210: generic_seq_210

- **正则**: `\bREF210[: ]\d{2,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: REF210: 55

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 211: generic_seq_211

- **正则**: `\bCODE211[:\-]?\d{4,8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: CODE211-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 212: generic_seq_212

- **正则**: `\bTOKEN212[A-Z]{3,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: TOKEN212XYZ

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 213: generic_seq_213

- **正则**: `\bREF213[: ]\d{2,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: REF213: 55

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 214: generic_seq_214

- **正则**: `\bCODE214[:\-]?\d{4,8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: CODE214-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 215: generic_seq_215

- **正则**: `\bTOKEN215[A-Z]{3,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: TOKEN215XYZ

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 216: generic_seq_216

- **正则**: `\bREF216[: ]\d{2,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: REF216: 55

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 217: generic_seq_217

- **正则**: `\bCODE217[:\-]?\d{4,8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: CODE217-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 218: generic_seq_218

- **正则**: `\bTOKEN218[A-Z]{3,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: TOKEN218XYZ

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 219: generic_seq_219

- **正则**: `\bREF219[: ]\d{2,6}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: REF219: 55

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 220: generic_seq_220

- **正则**: `\bCODE220[:\-]?\d{4,8}\b`

- **描述**: Imported from previous huge_rules (no description).

- **示例**: CODE220-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 221: mobile_dash_221

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1221-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 222: token_base64_222

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: d38660e7cc7ad2353fb7387bead5dfccbcbe

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 223: order_no_223

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100223

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 224: invoice_no_224

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200224

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 225: hex_32_225

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 6132198f056f5b54fa407dfd1c7be26d

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 226: uuid_compact_226

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: dc76369604cfbafaf6612b20b9d98b72

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 227: short_hex_227

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 80ffa70c

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 228: ipv4_228

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.228.174

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 229: datetime_iso_229

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-06T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 230: generic_code_230

- **正则**: `\bCODE230[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE230-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 231: email_variation_231

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user231@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 232: mobile_dash_232

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1232-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 233: token_base64_233

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: 2a79646528dcca9d43759eb60b33d584e165

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 234: order_no_234

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 235: invoice_no_235

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200235

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 236: hex_32_236

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: f1db0527a8262acbb826c8dc1ebedc0b

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 237: uuid_compact_237

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: 385b3cfb7a16ccf22bbcb54774278059

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 238: short_hex_238

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 9c84abe0

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 239: ipv4_239

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.239.207

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 240: datetime_iso_240

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-17T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 241: generic_code_241

- **正则**: `\bCODE241[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE241-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 242: email_variation_242

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user242@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 243: mobile_dash_243

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1243-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 244: token_base64_244

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: 9dac1d295df536cf655956ef58ef34649188

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 245: order_no_245

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100245

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 246: invoice_no_246

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200246

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 247: hex_32_247

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: ef1b7187d67efa8d420667453b1f4989

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 248: uuid_compact_248

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: 281e4d4fec8651c6745f0b27bb19b6eb

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 249: short_hex_249

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 4682f9f4

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 250: ipv4_250

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.250.240

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 251: datetime_iso_251

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-28T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 252: generic_code_252

- **正则**: `\bCODE252[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE252-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 253: email_variation_253

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user253@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 254: mobile_dash_254

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1254-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 255: token_base64_255

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: ccd1e3419b44ff6ec87acfe7b954ade9fe13

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 256: order_no_256

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100256

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 257: invoice_no_257

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200257

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 258: hex_32_258

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: e6fb93f8ed11f4470a2ebfa87c4be7da

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 259: uuid_compact_259

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: 295ac659ae8b3d2036aa21bbadba83e7

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 260: short_hex_260

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 72042383

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 261: ipv4_261

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.6.18

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 262: datetime_iso_262

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-11T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 263: generic_code_263

- **正则**: `\bCODE263[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE263-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 264: email_variation_264

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user264@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 265: mobile_dash_265

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1265-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 266: token_base64_266

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: f0d14a99068655529de75745b312c0eaf766

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 267: order_no_267

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100267

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 268: invoice_no_268

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200268

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 269: hex_32_269

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: a2cb7cb435e8972aef72811e60a05c4c

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 270: uuid_compact_270

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: da1e6919d8880e3cf65c4882de1b3ed1

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 271: short_hex_271

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: a0bb74fb

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 272: ipv4_272

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.17.51

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 273: datetime_iso_273

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-22T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 274: generic_code_274

- **正则**: `\bCODE274[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE274-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 275: email_variation_275

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user275@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 276: mobile_dash_276

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1276-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 277: token_base64_277

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: a61d4d781f5b70db7cc24b078ae7d69820f0

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 278: order_no_278

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100278

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 279: invoice_no_279

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200279

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 280: hex_32_280

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 62b32ed27b1837ee4ce98c1b466a2ba1

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 281: uuid_compact_281

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: 9a501f2e4f65c7d8c511d59d5d10efea

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 282: short_hex_282

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 1baaa450

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 283: ipv4_283

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.28.84

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 284: datetime_iso_284

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-05T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 285: generic_code_285

- **正则**: `\bCODE285[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE285-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 286: email_variation_286

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user286@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 287: mobile_dash_287

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1287-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 288: token_base64_288

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: 71ad6ec82554a9e522234046d55c857348ae

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 289: order_no_289

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100289

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 290: invoice_no_290

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200290

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 291: hex_32_291

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: c1b76b6c983c0ef01933a8c9a2fd59f3

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 292: uuid_compact_292

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: 78fa96714f79646bf12bb6e28c2d33f1

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 293: short_hex_293

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 46bbfbf4

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 294: ipv4_294

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.39.117

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 295: datetime_iso_295

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-16T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 296: generic_code_296

- **正则**: `\bCODE296[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE296-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 297: email_variation_297

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user297@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 298: mobile_dash_298

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1298-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 299: token_base64_299

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: d06b14925e7bde2c47a044ac028ac742ef0d

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 300: order_no_300

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100300

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 301: invoice_no_301

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200301

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 302: hex_32_302

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: fc6f036ce49059758c348000a8faeba9

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 303: uuid_compact_303

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: 0b0a52624fb64f5dc10dc662fe17691b

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 304: short_hex_304

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 0b6baa02

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 305: ipv4_305

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.50.150

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 306: datetime_iso_306

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-27T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 307: generic_code_307

- **正则**: `\bCODE307[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE307-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 308: email_variation_308

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user308@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 309: mobile_dash_309

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1309-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 310: token_base64_310

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: 993f7638449ebddaba6fc23760bec77a06eb

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 311: order_no_311

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100311

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 312: invoice_no_312

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200312

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 313: hex_32_313

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 56108a7369f669ea4f965a48951043b3

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 314: uuid_compact_314

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: a8a5853ac6d9daf327f488b5ef21bbb2

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 315: short_hex_315

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 7a24cd69

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 316: ipv4_316

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.61.183

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 317: datetime_iso_317

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-10T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 318: generic_code_318

- **正则**: `\bCODE318[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE318-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 319: email_variation_319

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user319@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 320: mobile_dash_320

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1320-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 321: token_base64_321

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: d825afecff6a0932a3af7d7e79c35081caf1

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 322: order_no_322

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100322

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 323: invoice_no_323

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200323

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 324: hex_32_324

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: c420292ce755023661768e9cc773afa4

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 325: uuid_compact_325

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: 29e276eabb93d22dddc6aef6b3062dd1

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 326: short_hex_326

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 7b73ef60

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 327: ipv4_327

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.72.216

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 328: datetime_iso_328

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-21T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 329: generic_code_329

- **正则**: `\bCODE329[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE329-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 330: email_variation_330

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user330@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 331: mobile_dash_331

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1331-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 332: token_base64_332

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: 23562cbb49d76b6248822ee78dcf2a8ec042

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 333: order_no_333

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100333

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 334: invoice_no_334

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200334

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 335: hex_32_335

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: cb90bab8efbca12705a510ee8e486afb

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 336: uuid_compact_336

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: dddffc3de67b5c23406201715a29ee26

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 337: short_hex_337

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 1befbcdb

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 338: ipv4_338

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.83.249

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 339: datetime_iso_339

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-04T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 340: generic_code_340

- **正则**: `\bCODE340[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE340-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 341: email_variation_341

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user341@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 342: mobile_dash_342

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1342-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 343: token_base64_343

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: b30d120dc416e42bec657c9da35f58a43ad7

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 344: order_no_344

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100344

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 345: invoice_no_345

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200345

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 346: hex_32_346

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 0624bc901152f43fec7312e4e1d95ebd

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 347: uuid_compact_347

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: b8c0ed1a57260a3ccf429e4386711857

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 348: short_hex_348

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 913967c0

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 349: ipv4_349

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.94.27

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 350: datetime_iso_350

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-15T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 351: generic_code_351

- **正则**: `\bCODE351[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE351-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 352: email_variation_352

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user352@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 353: mobile_dash_353

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1353-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 354: token_base64_354

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: e5cded04f71d74eb4050cff4ba3d7c0a8dd4

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 355: order_no_355

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100355

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 356: invoice_no_356

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200356

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 357: hex_32_357

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 27cb6a0962fb3f0920680f12cbddb13e

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 358: uuid_compact_358

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: 5aa0f4df26c1afd63ec5c3462a945e67

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 359: short_hex_359

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: d974ba4a

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 360: ipv4_360

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.105.60

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 361: datetime_iso_361

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-26T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 362: generic_code_362

- **正则**: `\bCODE362[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE362-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 363: email_variation_363

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user363@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 364: mobile_dash_364

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1364-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 365: token_base64_365

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: 997e60cb49fd67ee8a9632395bfcb4f89be4

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 366: order_no_366

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100366

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 367: invoice_no_367

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200367

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 368: hex_32_368

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: dd2243569b6a3029205cffee23bba970

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 369: uuid_compact_369

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: 67fb2932519727667758e676e35f9de4

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 370: short_hex_370

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: e95b832c

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 371: ipv4_371

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.116.93

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 372: datetime_iso_372

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-09T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 373: generic_code_373

- **正则**: `\bCODE373[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE373-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 374: email_variation_374

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user374@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 375: mobile_dash_375

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1375-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 376: token_base64_376

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: 803013960d2a414011aac509e94ba2831429

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 377: order_no_377

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100377

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 378: invoice_no_378

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200378

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 379: hex_32_379

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 0d86b91071f3f8ee8202e181a24b3bd2

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 380: uuid_compact_380

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: ec852de6502af8228084ada0ca2c5b50

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 381: short_hex_381

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 4a0091b9

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 382: ipv4_382

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.127.126

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 383: datetime_iso_383

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-20T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 384: generic_code_384

- **正则**: `\bCODE384[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE384-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 385: email_variation_385

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user385@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 386: mobile_dash_386

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1386-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 387: token_base64_387

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: 1099a8a279d5670a34cb09d740ade7d78efb

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 388: order_no_388

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100388

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 389: invoice_no_389

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200389

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 390: hex_32_390

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 5cfe3273c53243a3c9f1b7768fef21ca

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 391: uuid_compact_391

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: bf58e25f46a3661e6fd3298df53f6418

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 392: short_hex_392

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 01dae32b

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 393: ipv4_393

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.138.159

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 394: datetime_iso_394

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-03T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 395: generic_code_395

- **正则**: `\bCODE395[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE395-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 396: email_variation_396

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user396@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 397: mobile_dash_397

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1397-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 398: token_base64_398

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: 319f9cc31e62b41588b262160d14ba37b7b1

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 399: order_no_399

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100399

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 400: invoice_no_400

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200400

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 401: hex_32_401

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: b3b8d86cbb23c1a68143d6022bd9ca1a

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 402: uuid_compact_402

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: d0b9e4dd607e2ddab02d783be12a0ae2

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 403: short_hex_403

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: ab5a0ea0

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 404: ipv4_404

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.149.192

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 405: datetime_iso_405

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-14T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 406: generic_code_406

- **正则**: `\bCODE406[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE406-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 407: email_variation_407

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user407@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 408: mobile_dash_408

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1408-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 409: token_base64_409

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: 0da6798dbdd8caa3d0aa103e10f32095a96b

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 410: order_no_410

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100410

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 411: invoice_no_411

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200411

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 412: hex_32_412

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 9a140d96a0da78a87a3fe2eb3e30f580

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 413: uuid_compact_413

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: 92881a755589909515a5529e3dc20b59

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 414: short_hex_414

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: b9532481

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 415: ipv4_415

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.160.225

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 416: datetime_iso_416

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-25T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 417: generic_code_417

- **正则**: `\bCODE417[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE417-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 418: email_variation_418

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user418@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 419: mobile_dash_419

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1419-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 420: token_base64_420

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: b2f09424733a74b656fb70eeea95a31ab6f0

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 421: order_no_421

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100421

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 422: invoice_no_422

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200422

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 423: hex_32_423

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 8d986eb7e43d9f37542d1771a166e61e

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 424: uuid_compact_424

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: ffb5cd9595faf9b988ce100d3d8f7c8e

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 425: short_hex_425

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 500b6ddb

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 426: ipv4_426

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.171.3

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 427: datetime_iso_427

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-08T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 428: generic_code_428

- **正则**: `\bCODE428[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE428-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 429: email_variation_429

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user429@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 430: mobile_dash_430

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1430-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 431: token_base64_431

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: cb093759bdff80743419e07efb4a9eec6636

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 432: order_no_432

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100432

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 433: invoice_no_433

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200433

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 434: hex_32_434

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 99e0550fa4175fb7a85837c319ea183d

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 435: uuid_compact_435

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: 8d598e552597cefc9cd5ba07a9b7f880

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 436: short_hex_436

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: e429106d

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 437: ipv4_437

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.182.36

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 438: datetime_iso_438

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-19T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 439: generic_code_439

- **正则**: `\bCODE439[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE439-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 440: email_variation_440

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user440@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 441: mobile_dash_441

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1441-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 442: token_base64_442

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: d66932ceaf0b3b26bb360998e05375d4c203

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 443: order_no_443

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100443

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 444: invoice_no_444

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200444

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 445: hex_32_445

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: d837b5b5413119ee776bff67899f8300

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 446: uuid_compact_446

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: a6f274ffc4e4f4b4b489b005491d36c1

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 447: short_hex_447

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: e72cfeff

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 448: ipv4_448

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.193.69

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 449: datetime_iso_449

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-02T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 450: generic_code_450

- **正则**: `\bCODE450[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE450-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 451: email_variation_451

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user451@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 452: mobile_dash_452

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1452-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 453: token_base64_453

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: 7c2b4ff713fef1f46989f76a6f50983d49ae

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 454: order_no_454

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100454

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 455: invoice_no_455

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200455

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 456: hex_32_456

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 0054328b5df1bf8ae4ed92a9183796ab

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 457: uuid_compact_457

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: fbdde71ad0a961ec9c586fe5b971f7d1

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 458: short_hex_458

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 85624130

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 459: ipv4_459

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.204.102

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 460: datetime_iso_460

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-13T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 461: generic_code_461

- **正则**: `\bCODE461[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE461-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 462: email_variation_462

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user462@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 463: mobile_dash_463

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1463-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 464: token_base64_464

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: ecafb13efc50c0006e635ce28549ddbbf1b6

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 465: order_no_465

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100465

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 466: invoice_no_466

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200466

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 467: hex_32_467

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 24bf55ef996503f18578918ff09c393a

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 468: uuid_compact_468

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: c513e3226f3d77c9d969be434cf26696

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 469: short_hex_469

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 9111c73a

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 470: ipv4_470

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.215.135

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 471: datetime_iso_471

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-24T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 472: generic_code_472

- **正则**: `\bCODE472[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE472-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 473: email_variation_473

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user473@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 474: mobile_dash_474

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1474-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 475: token_base64_475

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: e434c121766d026393fd1a47fb6cacab5ef0

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 476: order_no_476

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100476

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 477: invoice_no_477

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200477

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 478: hex_32_478

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 17f275cd46121a6b2bc064da12c63001

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 479: uuid_compact_479

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: 1a89c745e4b1f605230ad8176f7dab97

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 480: short_hex_480

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 64a64662

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 481: ipv4_481

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.226.168

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 482: datetime_iso_482

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-07T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 483: generic_code_483

- **正则**: `\bCODE483[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE483-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 484: email_variation_484

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user484@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 485: mobile_dash_485

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1485-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 486: token_base64_486

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: 1d8f9db0f64cd586a77d8d1f5d43cd6e7d04

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 487: order_no_487

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100487

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 488: invoice_no_488

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200488

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 489: hex_32_489

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: e546f5d677a76318d3ed08e4a85d2e79

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 490: uuid_compact_490

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: 309dafd7c0375af8c09d3aed18c374a2

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 491: short_hex_491

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 0ef62b07

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 492: ipv4_492

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.237.201

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 493: datetime_iso_493

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-18T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 494: generic_code_494

- **正则**: `\bCODE494[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE494-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 495: email_variation_495

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user495@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 496: mobile_dash_496

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1496-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 497: token_base64_497

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: 64ac342175eb96cc838b48ef6e37f50e7380

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 498: order_no_498

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100498

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 499: invoice_no_499

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200499

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 500: hex_32_500

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 679c712641a3bc409033b2aeb4ea6567

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 501: uuid_compact_501

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: a8c302e5fb1cf6252038e1161ab13fe1

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 502: short_hex_502

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 4cb509f7

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 503: ipv4_503

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.248.234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 504: datetime_iso_504

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-01T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 505: generic_code_505

- **正则**: `\bCODE505[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE505-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 506: email_variation_506

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user506@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 507: mobile_dash_507

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1507-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 508: token_base64_508

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: d29cff3a9bd5e07b8e5975c362a78654389b

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 509: order_no_509

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100509

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 510: invoice_no_510

- **正则**: `\bINV[-_ ]?\d{6,12}\b`

- **描述**: 发票号码（INV 前缀）

- **示例**: INV200510

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 511: hex_32_511

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 32 字符十六进制散列（MD5-like）

- **示例**: 8bda7846187eaf0a02454b293bcc2238

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 512: uuid_compact_512

- **正则**: `\b[0-9a-fA-F]{32}\b`

- **描述**: 无横线 UUID 表示

- **示例**: b779b6cc3d38b101d792993c293df74c

- **风险级别**: 高风险

- **脱敏建议**: 应当使用掩码（如部分替换为***）存储或展示。

## 规则 513: short_hex_513

- **正则**: `\b[0-9a-fA-F]{8}\b`

- **描述**: 短 8 字节十六进制标识

- **示例**: 508d7d76

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 514: ipv4_514

- **正则**: `\b(?:\d{1,3}\.){3}\d{1,3}\b`

- **描述**: IPv4 地址

- **示例**: 10.0.4.12

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 515: datetime_iso_515

- **正则**: `\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\b`

- **描述**: ISO8601 UTC 时间戳

- **示例**: 2023-08-12T12:00:00Z

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 516: generic_code_516

- **正则**: `\bCODE516[:\-]?\d{4,8}\b`

- **描述**: 通用序列号样式

- **示例**: CODE516-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 517: email_variation_517

- **正则**: `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}`

- **描述**: 一般邮箱格式（短域）

- **示例**: user517@example.co

- **风险级别**: 中风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 518: mobile_dash_518

- **正则**: `\b1[3-9]\d{2}[-\s]?\d{4}[-\s]?\d{4}\b`

- **描述**: 中国大陆手机号带短横分隔

- **示例**: 138-1518-1234

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 519: token_base64_519

- **正则**: `[A-Za-z0-9_-]{20,300}`

- **描述**: 看起来像长令牌/密钥的字母数字串

- **示例**: f64b5d0e10d7df8ae7ed9147ed43e02c6353

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 520: order_no_520

- **正则**: `\bORD[-_ ]?\d{6,12}\b`

- **描述**: 订单号（ORD 前缀）

- **示例**: ORD-100520

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。

## 规则 521: iban

- **正则**: `\b[A-Z]{2}\d{2}[A-Z0-9]{4,30}\b`

- **描述**: IBAN 国际银行账号

- **示例**: GB29NWBK60161331926819

- **风险级别**: 一般风险

- **脱敏建议**: 应谨慎处理，避免公开展示。
