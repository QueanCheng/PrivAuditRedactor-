# Contributors

- 钱成 — Principal developer (initial prototype and rule curation)
- Open-source helpers and plugins (see plugins/)

> Note: This repository was iteratively developed and hand-reviewed.
